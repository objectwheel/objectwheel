// form.js

function form_onCompleted() {
    button1.clicked.connect(button1_onClicked)
    button2.clicked.connect(button2_onClicked)
    console.log("Form loaded.")
}

function button1_onClicked() {
    helloWorldLabel.text = qsTr("Button 1 Clicked!")
    helloWorldLabel.font.bold = true
}

function button2_onClicked() {
    helloWorldLabel.text = qsTr("Button 2 Clicked!")
    helloWorldLabel.font.bold = true
}