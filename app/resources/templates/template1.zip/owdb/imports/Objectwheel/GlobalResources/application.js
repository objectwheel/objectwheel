// application.js

function application_onCompleted() {
    button.clicked.connect(button_onClicked)
    console.log("Application loaded.")
}

function button_onClicked() {
    console.log("Hello, world!")
}