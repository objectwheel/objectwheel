// application.js

.import QtQuick 2.0 as QQ2

function application_onCompleted() {
    button.clicked.connect(button_onClicked)

    console.log("Application loaded.")
}

function button_onClicked() {
    console.log("Hello, world!")
}