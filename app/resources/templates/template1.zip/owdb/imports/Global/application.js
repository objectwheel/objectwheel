// application.js

function applicationWindow_onCompleted() {
    button.clicked.connect(button_onClicked)
}

function button_onClicked() {
    console.log("Hello, world!")
}
