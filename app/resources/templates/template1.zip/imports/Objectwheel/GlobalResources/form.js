// form.js

function form_onCompleted() {
    button.clicked.connect(button_onClicked)
    console.log("Form loaded.")
}

function button_onClicked() {
    console.log("Hello, world!")
}