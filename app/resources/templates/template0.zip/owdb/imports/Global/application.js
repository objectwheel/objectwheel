// application.js

.import QtQuick 2.0 as QQ2

function application_onCompleted() {
    console.log("Application loaded.")
}