// application.js

function window_onCompleted() {
    console.log("What's up dude!")
}
