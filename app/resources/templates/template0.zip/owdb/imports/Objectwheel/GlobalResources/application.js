// application.js

function application_onCompleted() {
    console.log("Application loaded.")
}