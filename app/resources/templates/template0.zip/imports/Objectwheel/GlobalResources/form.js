// form.js

function form_onCompleted() {
    console.log("Form loaded.")
}