var token = "";
var expires = 0;
var locked = false;

function updateData()
{
    getToken( function() {
        var http = new XMLHttpRequest();
        var body = {tags:[{name:"Temp"}]};
        var url = "https://time-series-store-predix.run.aws-usw02-pr.ice.predix.io/v1/datapoints/latest";
        http.open("POST", url, true);

        //Send the proper header information along with the request
        http.setRequestHeader("predix-zone-id", "ad58b1f6-08d2-4d42-b953-1d95a8f62c5d");
        http.setRequestHeader("authorization", "Bearer " + token);
        http.setRequestHeader("content-type", "application/json");

        http.onreadystatechange = function() { //Call a function when the state changes.
            if(http.readyState == 4 && http.status == 200) {
                var data = JSON.parse(http.responseText);
                var datapoints = data.tags[0].results[0].values;
                if (datapoints.length > 0) {
                    circularGauge.value = datapoints[0][1];
                }
            } else if (http.status != 200) {
                console.log("ERROR: Predix.js, Access denied.")
            }
        }

        http.send(JSON.stringify(body));
    });
}

function getToken( getData )
{
    if (locked == true)
        return;

    var time = (new Date).getTime();
    if (expires - time > 0) {
        getData();
        return;
    }

    var http = new XMLHttpRequest();
    var body = "client_id=mike&grant_type=client_credentials";
    var url = "https://096fd807-0897-4829-86b4-a3d745d0d6bd.predix-uaa.run.aws-usw02-pr.ice.predix.io/oauth/token";
    http.open("POST", url, true);

    //Send the proper header information along with the request
    http.setRequestHeader("Pragma", "no-cache");
    http.setRequestHeader("content-type", "application/x-www-form-urlencoded");
    http.setRequestHeader("Cache-Control", "no-cache" );
    http.setRequestHeader("authorization", "Basic bWlrZTptaWtl");

    http.onreadystatechange = function() { //Call a function when the state changes.
        if(http.readyState == 4 && http.status == 200) {
            var data = JSON.parse(http.responseText);
            expires = (new Date).getTime() + data.expires_in;
            token = data.access_token;
            getData();
        } else if (http.status != 200) {
            console.log("ERROR: Predix.js, Bad credentials. " + http.status)
        }
        locked = false;
    }

    http.send(body);
    locked = true;
}
